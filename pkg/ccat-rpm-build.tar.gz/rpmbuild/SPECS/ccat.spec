Name:           ccat
Version:        0.8.0
Release:        1%{?dist}
Summary:        File color filter

%global debug_package %{nil}

License:        GPL-3.0-only
URL:            https://www.ikjetil.no/blog/Linuxccat.php
Source0:        %{name}-%{version}.tar.gz

%description
ccat is a program that outputs text files to screen and colorizes the output.

%prep
%autosetup

%build
# Nothing to build. Precompiled binary.

%install
mkdir -p %{buildroot}/usr/bin
install -m 755 ccat %{buildroot}/usr/bin/ccat

mkdir -p %{buildroot}/usr/share/ccat/.ccat
install -m 644 *.ccrc %{buildroot}/usr/share/ccat/.ccat

%files
/usr/bin/ccat
/usr/share/ccat/.ccat/*.ccrc

%changelog
* Sun May 24 2026 Kjetil Kristoffer Solberg <post@ikjetil.no> - 0.8.0-1
- Initial RPM release
